package com.example.spotifyplaylistapp.model.enums;

public enum StyleName {
    POP, ROCK, JAZZ
}
